<html>
<head>
    <style>
                                       /*for pad*/
        @page{margin:0; }
        body{padding-bottom: 150px;padding-top: 100px;}
        .header, .footer{  position: fixed; }
        .header { top: 0px; }
        .header img{padding-top: 50px;padding-left: 30px}
        #triangle-topright {  width: 0;  height: 0;  border-top: 25px solid #000000;  border-left: 100px solid transparent;  position: absolute;  right: 0;  top: 0;  }
        .footer {  bottom: 90px; }
        .footer1, .footer2, .footer3{  width: 33%;  display: inline-block;  }
        .footer p{  padding-left:20px;  }
        .footerbg1{  height:30px;  background: #00033d;  }
        .footerbg2{  height:30px;  background: #28aaa9;  }
        .footerbg3{  height:30px;  background: #00033d;  }
        .main{padding-left: 50px;padding-right: 50px;}

                            /*for body*/


    </style>
</head>
<body>
<div class="header">
    <img src="@php echo $_SERVER["DOCUMENT_ROOT"].'/images/logo.png' @endphp" alt="">
    <span id="triangle-topright-black"></span>
    <span id="triangle-topright-blue"></span>
</div>

<div class="footer">
    <div class="footer1">
        <p>274, Shah Kabir Mazar Road</p>
        <p>+8801779379503</p>
        <p class="footerbg1"></p>
    </div>



    <div class="footer2">
        <p>http://itclanbd.com</p>
        <p>info@itclanbd.com</p>
        <p class="footerbg2"></p>
    </div>

    <div class="footer3">
        <p>fb.com/itclanbd</p>
        <p>twitter.com/itclanbd</p>
        <p class="footerbg3"></p>
    </div>

</div>

<div class="main">

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.


    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quotNayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quotNayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quotNayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quot

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quotNayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quotNayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quotNayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quotNayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quotNayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quotNayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.

    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quoted Nayeem as saying.
    Nayeem, who along with his family is visiting Malaysia, said Sabah Tani used to live with her mother in the Uttara residence where she was alone since last night as her mother went to her sister’s place.

    “Since last night many have tried to contact Sabah Tani over phone but failed” the Bangla daily quot

</div>




</body>


