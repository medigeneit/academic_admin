    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1 style="text-align: center">
                Invoice Sent Successfully
            </h1>
        </section>
    </div>
