<!DOCTYPE html>

<html>

<head>

    <title>Load PDF</title>

    <style type="text/css">

        table{

            width: 100%;

            border:1px solid black;

        }

        td, th{

            border:1px solid black;

        }

    </style>

</head>

<body>



<h2><img src="@php echo $_SERVER["DOCUMENT_ROOT"].'/images/logo.png' @endphp" alt=""></h2>

<table>

    <tr>

        <th>No.</th>

        <th>Name</th>

    </tr>

    <tr>

        <td>1</td>

        <td>Vimal Kashiyani</td>

    </tr>

    <tr>

        <td>2</td>

        <td>Hardik Savani</td>

    </tr>

    <tr>

        <td>1</td>

        <td>Harshad Pathak</td>

    </tr>

</table>



</body>

</html>