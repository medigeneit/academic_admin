<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>France Web Dictionary</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="main_container">
      <div class="header">
        <div class="logo">
          <a href="index.php"><img src="image/logo.png" alt=""></a>
        </div>
        <div class="menu">
          <nav class="navbar">
            <div class="">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
              </div>

              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  <li class="active"><a href="#">About us <span class="sr-only">(current)</span></a></li>
                  <li><a href="#">Our blog</a></li>
                  <li><a href="#">Contact us</a></li>
                  <li><a href="#">Advertise with us</a></li>
                  <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="#">Action</a></li>
                      <li><a href="#">Another action</a></li>
                      <li><a href="#">Something else here</a></li>
                      <li role="separator" class="divider"></li>
                      <li><a href="#">Separated link</a></li>
                      <li role="separator" class="divider"></li>
                      <li><a href="#">One more separated link</a></li>
                    </ul>
                  </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                  <li><a href="#">Sign In</a></li>
                  <li><a href="#">Register</a></li>
                </ul>
              </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
          </nav>
        </div>
        <div class="register"></div>
      </div>
      
      <div class="search_page">
        <div class="search_area">
          <div class="category">
            <select>
              <option value="volvo">Alimentation</option>
              <option value="saab">Saab</option>
              <option value="opel">Opel</option>
              <option value="audi">Audi</option>
            </select>
          </div>
          <div class="parent">
            <select>
              <option value="volvo">Paris 10</option>
              <option value="saab">Saab</option>
              <option value="opel">Opel</option>
              <option value="audi">Audi</option>
            </select>
          </div>
          <button type="button" class="btn btn-primary btn-lg">Success</button>
        </div>
      </div>
      <div class="search_item">
        <div class="ad_area"></div>
        <div class="searching_area">
          <div class="category_declaration">
            <label for="">Home > Paris 10 > Super Market > Alimentation</label>
            <p>Paris 10 - Alimentation</p>
          </div>
          <div class="search_result_area">

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>

            <div class="search_result">
              <div class="result_image">
                <img src="image/profile_image.png" alt="">
              </div>
              <div class="result_dec">
                <h4>Comptoir Du Bangal - Alimentation Generale</h4>
                <p>148, Rue du Faubourg Saint Denis, 75010 Paris</p>
                <p>Tél : 01 58 20 05 68</p>
                <p>Email :&nbsp<a href="mailto:example@gmail.com">sasuman12@yahoo.fr</a></p>
                <p>Web: <a href="www.comptoirdubangal.com">comptoirdubangal.com</a></p>
              </div>
            </div>
          </div>
          <div class="paginations">
            <div id="container">
              <div class="pagination">
                <a href="#" class="page gradient">first</a>
                <a href="#" class="page gradient">2</a>
                <a href="#" class="page gradient">3</a>
                <span class="page active">4</span>
                <a href="#" class="page gradient">5</a>
                <a href="#" class="page gradient">6</a>
                <a href="#" class="page gradient">last</a>
                <a href="#" class="page gradient next">Next</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer_bg2"></div>
      <div class="footer">
        <div class="footer_area">
          <div class="footer_menu">
            <ul>
              <li><a href="">About us</a></li>
              <li><a href="">Our blog</a></li>
              <li><a href="">Contact us</a></li>
              <li><a href="">Advertise with us</a></li>
            </ul>
          </div>
          <div class="social_icon">
            <ul>
              <li><a href="" class="youtube"></a></li>
              <li><a href="" class="google"></a></li>
              <li><a href="" class="twitter"></a></li>
              <li><a href="" class="facebook"></a></li>
            </ul>
          </div>
        </div>
        <div class="copyright">
          <p>Copyright © 2015 Amader Paris · Creation Site Web Par Rmwebsolution</p>
        </div>
      </div>
    </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>